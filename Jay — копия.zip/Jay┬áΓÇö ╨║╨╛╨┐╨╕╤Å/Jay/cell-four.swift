//
//  cell-four.swift
//  Jay
//
//  Created by POLINA FILACEVA on 23.03.2020.
//  Copyright © 2020 POLINA FILACEVA. All rights reserved.
//

import Foundation

import UIKit

class cellFour: UICollectionViewCell {
    @IBOutlet weak var lable1: UILabel!
    @IBOutlet weak var ingCell: UIImageView!
    @IBOutlet weak var textOne: UITextView!
    @IBOutlet weak var imageRating: UIImageView!
}

