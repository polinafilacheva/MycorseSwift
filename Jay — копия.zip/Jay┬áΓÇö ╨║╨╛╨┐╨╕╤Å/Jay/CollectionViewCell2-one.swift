//
//  CollectionViewCell2-one.swift
//  Jay
//
//  Created by POLINA FILACEVA on 23.03.2020.
//  Copyright © 2020 POLINA FILACEVA. All rights reserved.
//

import Foundation
import UIKit


