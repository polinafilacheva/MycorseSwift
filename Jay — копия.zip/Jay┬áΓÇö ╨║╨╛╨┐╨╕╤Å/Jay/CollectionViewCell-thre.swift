//
//  CollectionViewCell-thre.swift
//  Jay
//
//  Created by POLINA FILACEVA on 12.03.2020.
//  Copyright © 2020 POLINA FILACEVA. All rights reserved.
//

import UIKit

class CollectionViewCell_thre: UICollectionViewCell {
    
    @IBOutlet weak var imgCell2: UIImageView!
    @IBOutlet weak var labeleCall2: UILabel!
    @IBOutlet weak var textCell2: UILabel!
    
}
