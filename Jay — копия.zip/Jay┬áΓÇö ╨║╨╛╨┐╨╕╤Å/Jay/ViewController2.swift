//
//  ViewController2.swift
//  Jay
//
//  Created by POLINA FILACEVA on 23.03.2020.
//  Copyright © 2020 POLINA FILACEVA. All rights reserved.
//

import UIKit

class ViewController2: UIViewController {
 


    @IBOutlet weak var imageCard: UIImageView!
    
    @IBOutlet weak var textCard: UITextView!
    @IBOutlet weak var lableCard: UILabel!
    @IBOutlet weak var button: UIButton!
    

}


        
        
        func viewDidLoad() {
            viewDidLoad()
            
            let image = UIImage(named: "img.pmg")

}

