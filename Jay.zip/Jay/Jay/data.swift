//  data.swift
//  Jay
//  Created by POLINA FILACEVA on 12.03.2020.
//  Copyright © 2020 POLINA FILACEVA. All rights reserved.

import Foundation
import UIKit

struct Data {
    var name = ""
    var photo : UIImage?
    var text = ""
}
